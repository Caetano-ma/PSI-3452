# Contexto do projeto: Carregador de Célula Fotovoltaica (CI CMOS)

## Instruções para o assistente que receber este arquivo

- Responder em português (pt-BR).
- **Perguntar antes de supor.** O usuário pediu explicitamente que dúvidas sejam esclarecidas antes de qualquer suposição de projeto.
- O projeto é **didático**. O usuário vai projetar ele mesmo os circuitos em nível de transistor, então as arquiteturas propostas precisam ser **simples e factíveis à mão**.
- O diagrama de blocos digitalizado acompanha este arquivo: `carregador_fv_diagrama.svg`.

## Resumo

CI CMOS de 130 nm que coleta energia de **uma célula fotovoltaica única de silício amorfo** (energy harvesting de ambiente interno, tipo calculadora) e carrega **uma bateria Li-ion de 1 célula** com um conversor boost.

O projeto se inspira no **TI bq25504**, mas com os módulos simplificados para serem viáveis em nível de transistor.

**Etapa atual:** a especificação de blocos e pinos está concluída.
**Próximo passo:** pesquisar arquiteturas analógicas para cada módulo.

## Conexões (netlist de blocos)

| Sinal | Origem | Destino | Observação |
|---|---|---|---|
| VIN_DC | célula FV (externa) | Boost Charge Controller | 0,4 a 0,8 V |
| LBST | indutor externo | Boost Charge Controller | nó de chaveamento do indutor |
| VSTOR | Boost Charge Controller | bateria + capacitores de saída | ligado direto à bateria, sem chave (VSTOR ≈ VBAT) |
| VBAT | bateria | Cold-Start e Battery Threshold Control | 0 a 4,2 V |
| TRIGGER | fonte externa | Cold-Start | alimentação de partida quando a bateria não consegue dar partida |
| VDD | Cold-Start | Oscilador | tensão regulada constante |
| CLK | Oscilador | Boost Charge Controller | **somente** para o boost |
| CTRL_LOW | Battery Threshold Control | Cold-Start | ativo em nível baixo |
| CTRL_HIGH | Battery Threshold Control | Cold-Start | ativo em nível baixo |
| T_R, T_U, T_UH, T_D, T_DH | Battery Threshold Control | divisor resistivo externo | ver abaixo |
| GND | todos os blocos | — | — |

## Especificação dos módulos

### 1. Cold-Start (regulador de tensão)

Foi reduzido a um regulador cuja função é alimentar o oscilador com uma tensão constante.

- **Entradas:**
  - VBAT: fonte normal.
  - TRIGGER: fonte alternativa de partida.
  - CTRL_LOW e CTRL_HIGH.
- **Saída:** VDD para o Oscilador. O nível ainda será definido junto com o oscilador e o PDK.

**Lógica de controle** (os sinais são ativos em nível baixo, então "1 lógico" corresponde a 0 V):

| LOW | HIGH | Situação | Ação |
|---|---|---|---|
| 0 | 0 | T_D < VBAT < T_U | regula a partir de VBAT, liga o oscilador (carregando) |
| 1 | 0 | VBAT < T_D | usa TRIGGER como fonte em vez de VBAT |
| 0 | 1 | VBAT > T_U | não liga o oscilador (a carga para) |
| 1 | 1 | sistema sem energia | partida: o cold-start "liga" o sistema a partir do TRIGGER |

Notas sobre a lógica:

- O estado 1-1 nunca ocorre por medição, porque VBAT não pode estar abaixo de T_D e acima de T_U ao mesmo tempo. Ele funciona como código de power-on.
- Com a lógica ativa-baixa, o estado sem energia (todos os nós em 0 V) cai automaticamente em 1-1. O mesmo vale para VBAT baixo demais para os comparadores operarem: as saídas vão a 0 V, o estado ativo, e o sistema falha para o lado seguro.

### 2. Oscilador

- **Entrada:** VDD, vinda do Cold-Start.
- **Saída:** CLK, enviado só para o Boost.
- **Frequência:** a faixa original era de 900 MHz a 2 GHz, mas foi **descartada** por causa das perdas de chaveamento (C·V²·f) diante de uma potência disponível da ordem de µW. Ficou decidido **reduzir consideravelmente**. O valor fica para a etapa de arquitetura; a sugestão é da ordem de centenas de kHz a poucos MHz.
- **Requisito:** sem VDD, o CLK precisa cair para 0 V, para que a chave NMOS do boost fique **aberta**. Nenhum inversor entre o oscilador e o gate pode ser alimentado por outra fonte.

### 3. Battery Threshold Control

- **Comparadores contínuos, sem clock.** Essa escolha evita o travamento que existiria com comparadores amostrados: se o oscilador estivesse desligado, um comparador amostrado ficaria congelado com HIGH ativo.
- **Consumo:** baixo, com bias da ordem de dezenas de nA, possivelmente em sublimiar. A velocidade não é crítica.
- **Referência de tensão:** **interna ao bloco**, sem bloco adicional. Ela precisa ser independente de VBAT. O tipo ainda não foi escolhido; as opções levantadas foram referência baseada em Vth, beta-multiplier e diodos empilhados.
- **Divisor resistivo externo:**
  - T_R: saída. Liga VBAT ao topo do divisor (ramo da resistência total).
  - T_U: entrada. Tap do limite superior.
  - T_D: entrada. Tap do limite inferior.
  - Fundo do divisor no GND.
- **Histerese por realimentação no divisor:** a saída de cada comparador aciona um NMOS interno que curto-circuita um resistor de histerese externo, ligado pelos pinos **T_UH** e **T_DH**, que foram adicionados para isso.
- **Saídas:** CTRL_LOW e CTRL_HIGH, ativas em nível baixo.
- **Limiares típicos de Li-ion (a confirmar):** superior em cerca de 4,2 V; inferior entre 2,5 e 3,0 V; histerese de algumas dezenas de mV.

### 4. Boost Charge Controller

- Controle por **corrente de referência fixa**.
- **Entradas:** VIN_DC, LBST e CLK.
- **Saída:** VSTOR, até cerca de 4,2 V.
- **Não tem sinal de enable.** O boost para por **falta de CLK**, decisão tomada para manter os blocos simples.
- **Razão de conversão:** de 0,4 V até 4,2 V, cerca de 10x, com duty cycle de aproximadamente 90% no pior caso.
- O boost **não precisa partir sozinho a partir de VIN_DC**, porque a partida vem do TRIGGER.
- **Retificador:** precisa bloquear o retorno da bateria para a célula quando a chave estiver parada. Um diodo atende; um PMOS síncrono controlado pelo clock não atenderia.

## Pesquisa sobre VIN_DC (células de calculadora / silício amorfo)

- Uma célula individual de a-Si tem Voc de até cerca de 0,8 V. A Voc varia pouco com a luz, enquanto a corrente é proporcional à iluminação e à área (EnOcean AN207: https://www.enocean.com/wp-content/uploads/application-notes/AN207_ECS310_ECS320_SOLAR_PANEL_2026.pdf).
- Os módulos de calculadora são várias células em série. Exemplos:
  - Panasonic AM-1454CA: Voc de 2,4 V e Isc de 35 µA a 200 lx; operação em 1,5 V e 31 µA, o que dá cerca de 46 µW (https://www.masterelectronics.com/en/productdetail/panasonic-electronic-components/am1454ca-54955771.html).
  - SC-01: Voc de 4,0 V e operação em 3,0 V e 17 µA a 200 lx (https://www.imagesco.com/solar/solar-cells.html).
- O bq25504, como referência, aceita VIN_DC de 130 mV a 3 V após o cold-start. O MPP de células solares fica em torno de 80% da Voc (https://ti.com/lit/gpn/BQ25504).
- **Decisão:** usar uma **célula única de 0,4 a 0,8 V**. A potência disponível é da ordem de µW a dezenas de µW em luz interna.

## Pendências

1. Topologia exata do divisor externo com os resistores de histerese: onde ficam os resistores ligados a T_UH e T_DH e em que nó cada NMOS fecha.
2. Tipo de referência de tensão dentro do Battery Threshold Control.
3. Frequência do clock.
4. Nível de VDD do regulador.
5. Valores dos limiares e da histerese.
6. Valor da corrente de referência do boost.
7. **Dispositivos e PDK de 130 nm.** Os blocos ligados a VBAT/VSTOR (regulador, comparadores, chave e retificador do boost) precisam suportar VDS e VGS de até 4,2 V, o que normalmente exige óxido espesso. Pergunta ainda não respondida pelo usuário: quais modelos ou qual PDK serão usados.
8. Faixa de corrente da célula única escolhida, que depende da área.

## Próximo passo

Pesquisar **arquiteturas analógicas simples, em nível de transistor**, para cada módulo:

- regulador do cold-start com seleção de fonte (VBAT ou TRIGGER);
- oscilador de baixo consumo, com saída em 0 V quando sem alimentação;
- comparador contínuo de nA com referência interna e histerese via divisor;
- boost com controle por corrente de referência fixa e retificador por diodo.
